import React from 'react';

export type Pose = {x: number; y: number; l: number; rot: number; a: [number, number]; b: [number, number]; c: [number, number]; d: [number, number]};
export const GROUND = 1400;
const TL = 125, UA = 72, FA = 70, TH = 92, SH = 92, HR = 40;
const rad = (d: number) => (d * Math.PI) / 180;
type V = [number, number];
const vec = (a: number, len: number, dir: number): V => [Math.sin(rad(a)) * len * dir, Math.cos(rad(a)) * len];

type Props = {pose: Pose; dir: 1 | -1; color: string; dark: string; band: string; t: number; glow?: string; opacity?: number};

// Sudut diukur dari "lurus ke bawah", positif = ke arah hadap. Siku/lutut relatif terhadap tulang atas.
export const Stickman: React.FC<Props> = ({pose, dir, color, dark, band, t, glow, opacity = 1}) => {
  const foot = (q: V) => Math.cos(rad(q[0])) * TH + Math.cos(rad(q[0] + q[1])) * SH;
  const hipY = GROUND - Math.max(foot(pose.c), foot(pose.d)) - pose.y; // kaki selalu menapak tanah
  const S: V = [Math.sin(rad(pose.l)) * TL * dir, -Math.cos(rad(pose.l)) * TL];
  const Hd: V = [S[0] + Math.sin(rad(pose.l)) * (HR + 8) * dir, S[1] - Math.cos(rad(pose.l)) * (HR + 8)];
  const limb = (o: V, q: V, l1: number, l2: number) => {
    const p1 = vec(q[0], l1, dir);
    const k: V = [o[0] + p1[0], o[1] + p1[1]];
    const p2 = vec(q[0] + q[1], l2, dir);
    const e: V = [k[0] + p2[0], k[1] + p2[1]];
    return {pts: `${o[0]},${o[1]} ${k[0]},${k[1]} ${e[0]},${e[1]}`, end: e};
  };
  const arm = (q: V) => limb(S, q, UA, FA);
  const leg = (q: V) => limb([0, 0], q, TH, SH);
  const b = arm(pose.b), d = leg(pose.d), c = leg(pose.c), a = arm(pose.a);
  const w = Math.sin(t / 2.2);
  const bx = Hd[0] - dir * HR * 0.95, by = Hd[1] - 10;

  return (
    <g
      transform={`translate(${pose.x} ${hipY}) rotate(${-(pose.rot % 360) * dir})`}
      opacity={opacity}
      fill="none"
      strokeLinecap="round"
      strokeLinejoin="round"
      style={{filter: glow ? `drop-shadow(0 0 16px ${glow})` : undefined}}
    >
      <polyline points={b.pts} stroke={dark} strokeWidth={15} />
      <polyline points={d.pts} stroke={dark} strokeWidth={16} />
      <circle cx={b.end[0]} cy={b.end[1]} r={11} fill={dark} stroke="none" />
      <line x1={0} y1={0} x2={S[0]} y2={S[1]} stroke={color} strokeWidth={19} />
      <polyline points={`${bx},${by} ${bx - dir * (30 + 10 * w)},${by + 10 + 6 * Math.cos(t / 2)} ${bx - dir * (60 + 14 * Math.sin(t / 2.2 + 1))},${by + 6 + 10 * Math.cos(t / 2 + 1)}`} stroke={band} strokeWidth={7} />
      <circle cx={Hd[0]} cy={Hd[1]} r={HR} fill="#0a0716" stroke={color} strokeWidth={12} />
      <line x1={Hd[0] - HR + 2} y1={Hd[1] - 14} x2={Hd[0] + HR - 2} y2={Hd[1] - 14} stroke={band} strokeWidth={9} />
      <line x1={Hd[0] + dir * 6} y1={Hd[1] - 2} x2={Hd[0] + dir * 28} y2={Hd[1] + 7} stroke="#fff" strokeWidth={6} />
      <polyline points={c.pts} stroke={color} strokeWidth={17} />
      <polyline points={a.pts} stroke={color} strokeWidth={16} />
      <circle cx={a.end[0]} cy={a.end[1]} r={12} fill={color} stroke="none" />
    </g>
  );
};
