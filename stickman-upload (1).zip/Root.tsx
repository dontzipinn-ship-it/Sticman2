import {Composition} from 'remotion';
import {Fight} from './Fight';

export const Root = () => (
  <Composition id="StickmanFight" component={Fight} durationInFrames={660} fps={30} width={1080} height={1920} />
);
