"""Sintesis semua SFX + BGM (WAV mono 44.1kHz) ke public/sfx. Butuh: numpy."""
import os, wave
import numpy as np

SR = 44100
rng = np.random.default_rng(7)
OUT = os.path.join(os.path.dirname(__file__), '..', 'public', 'sfx')
os.makedirs(OUT, exist_ok=True)

T = lambda d: np.arange(int(SR * d)) / SR
env = lambda d, k: np.exp(-T(d) * k)
noise = lambda d: rng.standard_normal(int(SR * d))

def bp(x, lo, hi):
    X = np.fft.rfft(x); f = np.fft.rfftfreq(len(x), 1 / SR)
    X[(f < lo) | (f > hi)] = 0
    return np.fft.irfft(X, len(x))

def sweep(d, f0, f1):
    t = T(d); f = f0 * (f1 / f0) ** (t / d)
    return np.sin(2 * np.pi * np.cumsum(f) / SR)

def tones(d, freqs, k):
    t = T(d)
    return sum(np.sin(2 * np.pi * f * t) * np.exp(-t * (k + i * 0.4)) for i, f in enumerate(freqs))

def save(name, x, v=0.9):
    x = np.asarray(x, dtype=float)
    x = x / (np.abs(x).max() + 1e-9) * v
    n = min(len(x), int(SR * 0.01)); x[-n:] *= np.linspace(1, 0, n)
    with wave.open(os.path.join(OUT, name + '.wav'), 'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes((x * 32767).astype('<i2').tobytes())

def place(buf, x, at):
    i = int(at * SR); n = min(len(x), len(buf) - i)
    if n > 0: buf[i:i + n] += x[:n]

save('punch', sweep(.3, 170, 45) * env(.3, 14) + bp(noise(.3), 700, 6000) * env(.3, 30) * .6)
save('kick', sweep(.4, 130, 38) * env(.4, 9) + bp(noise(.4), 300, 4000) * env(.4, 22) * .7)
save('block', tones(.35, [820, 1240, 2010, 3100], 18) * .3 + bp(noise(.35), 1500, 9000) * env(.35, 60) * .5)
save('clash', tones(1.2, [540, 810, 1530, 2300], 5) * .35 + sweep(1.2, 110, 30) * env(1.2, 4) * 1.3 + bp(noise(1.2), 800, 8000) * env(1.2, 10) * .6)
save('boom', sweep(1.3, 100, 28) * env(1.3, 3.2) * 1.2 + bp(noise(1.3), 40, 1800) * env(1.3, 5) * .8)
save('big', sweep(2.4, 80, 22) * env(2.4, 1.8) * 1.3 + bp(noise(2.4), 60, 6000) * env(2.4, 3) * .8 + tones(2.4, [400, 613, 1190], 2.5) * .12, 1.0)
save('thud', sweep(.45, 95, 40) * env(.45, 10) + bp(noise(.45), 60, 700) * env(.45, 16) * .6)

d = .5; t = T(d)
save('whoosh', bp(noise(d), 500, 5000) * np.sin(np.pi * t / d) ** 2, .7)

d = 1.1; t = T(d)
save('dash', sweep(d, 160, 1800) * (t / d) ** 2 * .4 + bp(noise(d), 300, 8000) * (t / d) ** 1.5, .85)

hb = np.zeros(int(SR * .6))
place(hb, sweep(.18, 75, 38) * env(.18, 22), 0); place(hb, sweep(.18, 70, 36) * env(.18, 22) * .8, .22)
save('heart', hb, .95)

d = 2.0; t = T(d); ph = 2 * np.pi * np.cumsum(70 * (330 / 70) ** (t / d)) / SR
save('rise', sum(np.sin(k * ph) / k for k in range(1, 5)) * (t / d) ** 2 + bp(noise(d), 200, 3000) * (t / d) ** 2 * .3, .85)

d = 3.5; t = T(d)
save('gong', sum(np.sin(2 * np.pi * f * t) * np.exp(-t * (0.9 + i * 0.35)) for i, f in enumerate([110, 148, 221, 276, 330, 415, 520])) * np.minimum(1, t * 80), .9)

w = np.zeros(int(SR * 1.8))
for i, f in enumerate([523.25, 659.25, 783.99, 1046.5]):
    place(w, np.sin(2 * np.pi * f * T(1.2)) * env(1.2, 3), i * .12)
save('win', w, .7)

# BGM tegang 22 detik: drone + denyut bass makin cepat + riser
d = 22; t = T(d)
bgm = (np.sin(2 * np.pi * 55 * t) + .6 * np.sin(2 * np.pi * 82.4 * t) + .4 * np.sin(2 * np.pi * 110.5 * t + np.sin(t * .5))) * (0.55 + 0.45 * np.sin(2 * np.pi * .08 * t))
bgm += bp(noise(d), 200, 4000) * (t / d) ** 3 * .35
b = 0.0
while b < d - .3:
    place(bgm, sweep(.25, 90, 40) * env(.25, 14) * (.8 + 1.4 * b / d), b)
    b += 0.75 - 0.35 * (b / d)
bgm *= np.minimum(1, t / 1.5) * np.minimum(1, (d - t) / 1.0)
save('bgm', bgm, .8)
print('SFX selesai ->', os.path.abspath(OUT))
