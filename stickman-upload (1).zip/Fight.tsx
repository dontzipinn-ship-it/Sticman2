import React from 'react';
import {AbsoluteFill, Audio, Sequence, interpolate as I, random, staticFile, useCurrentFrame} from 'remotion';
import {loadFont} from '@remotion/google-fonts/Bangers';
import {GROUND, Pose, Stickman} from './stickman';
import {A_KEYS, B_KEYS, DUST, EVENTS, GameEvent, SFX, poseAt, realFrame, simTime} from './choreo';

const {fontFamily} = loadFont();
const C = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const BLUE = '#38bdf8', RED = '#fb7185';
const inR = (t: number, r: number[][]) => r.some(([a, b]) => t >= a && t <= b);

// ---------- Latar kota malam ----------
const mk = (seed: string, n: number, x0: number, h0: number, h1: number) => {
  let x = x0;
  const out: {x: number; w: number; h: number; win: {x: number; y: number}[]}[] = [];
  for (let i = 0; i < n; i++) {
    const w = 90 + random(`${seed}w${i}`) * 90, h = h0 + random(`${seed}h${i}`) * (h1 - h0);
    const win: {x: number; y: number}[] = [];
    for (let r = 0; r < 9; r++) for (let c = 0; c < Math.floor(w / 28); c++) if (random(`${seed}${i}-${r}-${c}`) > 0.72) win.push({x: x + 10 + c * 28, y: GROUND - h + 20 + r * 36});
    out.push({x, w, h, win});
    x += w - 8;
  }
  return out;
};
const FAR = mk('f', 16, -420, 300, 680), NEAR = mk('n', 12, -460, 200, 420);

const Bg: React.FC<{cx: number; f: number}> = ({cx, f}) => {
  const off = (k: number) => (cx - 540) * k;
  return (
    <g>
      <rect x={-600} y={-600} width={2280} height={3000} fill="url(#sky)" />
      {Array.from({length: 70}, (_, i) => (
        <circle key={i} cx={-300 + random(`sx${i}`) * 1680} cy={random(`sy${i}`) * 900} r={1 + random(`sr${i}`) * 2} fill="#fff" opacity={0.3 + 0.5 * Math.abs(Math.sin(f / 20 + i))} />
      ))}
      <g transform={`translate(${off(0.05)} 0)`}>
        <circle cx={780} cy={560} r={280} fill="#ff9a5a" opacity={0.1} />
        <circle cx={780} cy={560} r={160} fill="url(#moon)" />
      </g>
      <g transform={`translate(${off(0.15)} 0)`}>
        {FAR.map((b, i) => (
          <g key={i}>
            <rect x={b.x} y={GROUND - b.h} width={b.w} height={b.h + 20} fill="#170b2e" />
            {b.win.map((w, j) => <rect key={j} x={w.x} y={w.y} width={10} height={14} fill="#ffcf6b" opacity={0.55} />)}
          </g>
        ))}
      </g>
      <g transform={`translate(${off(0.35)} 0)`}>
        {NEAR.map((b, i) => <rect key={i} x={b.x} y={GROUND - b.h} width={b.w} height={b.h + 20} fill="#0b0618" />)}
      </g>
      <rect x={-600} y={GROUND} width={2280} height={1200} fill="url(#ground)" />
      <rect x={-600} y={GROUND - 3} width={2280} height={6} fill="#ff5ea8" opacity={0.85} style={{filter: 'drop-shadow(0 0 10px #ff5ea8)'}} />
      {Array.from({length: 8}, (_, i) => <line key={i} x1={-600} x2={1680} y1={GROUND + (i + 1) ** 2 * 8} y2={GROUND + (i + 1) ** 2 * 8} stroke="#fff" strokeOpacity={0.07} strokeWidth={2} />)}
      {Array.from({length: 17}, (_, k) => <line key={k} x1={540 + (k - 8) * 60} y1={GROUND} x2={540 + (k - 8) * 420} y2={GROUND + 520} stroke="#fff" strokeOpacity={0.05} strokeWidth={2} />)}
      {Array.from({length: 28}, (_, i) => {
        const r = random(`em${i}`);
        const y = GROUND + 100 - ((f * (1 + r * 2) + r * 1000) % 1500);
        return <circle key={i} cx={random(`ex${i}`) * 1500 - 200 + Math.sin(f / 15 + i) * 20} cy={y} r={2 + r * 3} fill="#ffb25a" opacity={0.5} />;
      })}
    </g>
  );
};

// ---------- Efek ----------
const Txt: React.FC<{x: number; y: number; size: number; fill: string; stroke?: string; rot?: number; scale?: number; op?: number; children: string}> = ({x, y, size, fill, stroke = '#000', rot = 0, scale = 1, op = 1, children}) => (
  <text x={x} y={y} fontSize={size} fontFamily={fontFamily} fill={fill} stroke={stroke} strokeWidth={size * 0.1} paintOrder="stroke" strokeLinejoin="round" textAnchor="middle" opacity={op}
    transform={`rotate(${rot} ${x} ${y}) translate(${x} ${y}) scale(${scale}) translate(${-x} ${-y})`}>
    {children}
  </text>
);

const FX: React.FC<{e: GameEvent; t: number}> = ({e, t}) => {
  const l = t - e.t;
  if (l < 0 || l > 34) return null;
  const {x, y, power: p} = e;
  const R = (50 + 45 * p) * I(l, [0, 3, 10], [0.3, 1, 1.25], C);
  const star = Array.from({length: 24}, (_, i) => {
    const r = (i % 2 ? 0.45 : 1) * R * (0.8 + 0.4 * random(`st${e.t}-${i}`));
    const a = (i * Math.PI) / 12;
    return `${x + Math.cos(a) * r},${y + Math.sin(a) * r}`;
  }).join(' ');
  const lx = Math.min(880, Math.max(200, x));
  return (
    <g>
      {e.star !== false && <polygon points={star} fill={e.col ?? '#fff3a0'} stroke="#ff8a00" strokeWidth={6} opacity={I(l, [0, 9, 13], [1, 1, 0], C)} />}
      {Array.from({length: 12}, (_, i) => {
        const a = random(`sp${e.t}-${i}`) * Math.PI * 2;
        const d0 = I(l, [0, 14], [20, 110 + random(`sd${e.t}-${i}`) * (100 + 60 * p)], C);
        const len = 34 * (1 - l / 16);
        if (len <= 0) return null;
        return <line key={i} x1={x + Math.cos(a) * d0} y1={y + Math.sin(a) * d0} x2={x + Math.cos(a) * (d0 + len)} y2={y + Math.sin(a) * (d0 + len)} stroke="#fff" strokeWidth={5} strokeLinecap="round" />;
      })}
      <circle cx={x} cy={y} r={l * (14 + 10 * p)} fill="none" stroke="#fff" strokeWidth={Math.max(1, 10 * (1 - l / 18))} opacity={Math.max(0, 1 - l / 18)} />
      {e.label && <Txt x={lx} y={y - 130 - p * 30} size={110 + p * 40} fill="#ffe066" stroke="#c2185b" rot={-8} scale={I(l, [0, 3, 5, 20, 26], [0.2, 1.3, 1, 1, 0], C)}>{e.label}</Txt>}
    </g>
  );
};

const Dust: React.FC<{d: {t: number; x: number; s: number}; t: number}> = ({d, t}) => {
  const l = t - d.t;
  if (l < 0 || l > 30) return null;
  return (
    <g>
      {Array.from({length: 9}, (_, i) => {
        const dir = i % 2 ? 1 : -1;
        const sp = (20 + random(`d${d.t}${i}`) * 40) * d.s;
        const r = (14 + random(`dr${d.t}${i}`) * 18) * d.s * (1 + l / 20);
        return <circle key={i} cx={d.x + dir * (10 + (l * sp) / 6) * (0.6 + i * 0.1)} cy={GROUND - r * 0.6 - l * 1.2} r={r} fill="#d9c9ff" opacity={0.4 * (1 - l / 30)} />;
      })}
    </g>
  );
};

const Aura: React.FC<{x: number; k: number; t: number}> = ({x, k, t}) =>
  k <= 0 ? null : (
    <g opacity={k}>
      <ellipse cx={x} cy={GROUND - 170} rx={150 + 20 * Math.sin(t / 2)} ry={270} fill="url(#aura)" />
      {Array.from({length: 16}, (_, i) => {
        const ph = (t * 7 + i * 53) % 380;
        const xx = x - 80 + random(`au${i}`) * 160 + Math.sin(t / 5 + i) * 14;
        return <line key={i} x1={xx} y1={GROUND - ph} x2={xx} y2={GROUND - ph - 70 - random(`al${i}`) * 50} stroke={i % 2 ? '#ffd23f' : '#fff3a0'} strokeWidth={5 + random(`aw${i}`) * 5} strokeLinecap="round" opacity={1 - ph / 380} />;
      })}
    </g>
  );

const Speed: React.FC<{k: number; f: number}> = ({k, f}) =>
  k <= 0 ? null : (
    <g opacity={Math.min(1, k)}>
      {Array.from({length: 44}, (_, i) => {
        const s = `${i}-${Math.floor(f / 2)}`;
        const a = random('a' + s) * Math.PI * 2, r0 = 380 + random('r' + s) * 260, r1 = r0 + 260 + random('l' + s) * 700;
        return <line key={i} x1={540 + Math.cos(a) * r0} y1={1150 + Math.sin(a) * r0 * 1.3} x2={540 + Math.cos(a) * r1} y2={1150 + Math.sin(a) * r1 * 1.3} stroke="#fff" strokeWidth={2 + random('w' + s) * 6} opacity={0.35 + 0.3 * random('o' + s)} strokeLinecap="round" />;
      })}
    </g>
  );

const Shadow: React.FC<{p: Pose}> = ({p}) => {
  const k = Math.max(0.3, 1 - Math.max(0, p.y) / 450);
  return <ellipse cx={p.x} cy={GROUND + 6} rx={80 * k} ry={13 * k} fill="#000" opacity={0.45 * k} />;
};

// ---------- HP ----------
const hpAt = (t: number, who: 'A' | 'B') => {
  let h = 100;
  for (const e of EVENTS) if ((e.v === who || e.v === 'both') && e.dmg) h -= e.dmg * I(t, [e.t, e.t + 6], [0, 1], C);
  return Math.max(0, h);
};
const hpCol = (h: number) => (h > 50 ? '#4ade80' : h > 25 ? '#facc15' : '#ef4444');

// ---------- Scene ----------
export const Fight: React.FC = () => {
  const frame = useCurrentFrame();
  const t = simTime(frame);
  const br = (p: Pose): Pose => (p.y > -100 ? {...p, y: p.y + Math.sin(t / 4) * 3} : p);
  const pa = br(poseAt(A_KEYS, t)), pb = br(poseAt(B_KEYS, t));

  // kamera
  const zs = I(t, [0, 90, 112, 340, 360, 428, 436, 452, 468, 474, 520, 560], [1, 1.1, 1, 1, 1.05, 1.28, 1.35, 1.2, 1.5, 1.3, 1.1, 1], C);
  const fw = I(t, [0, 350, 380, 428, 440, 468, 500, 560], [0.5, 0.5, 0.2, 0.2, 0.5, 0.65, 0.8, 0.7], C);
  const roll = I(t, [440, 468, 500], [0, -3, 0], C);
  let pz = 0, flash = 0, shx = 0, shy = 0;
  for (const e of EVENTS) {
    const l = t - e.t;
    if (l < 0) continue;
    pz += e.power * 0.035 * Math.exp(-l / 7);
    if (e.power >= 0.8) flash = Math.max(flash, Math.min(0.9, e.power * 0.4) * Math.exp(-l / 3));
    if (l < 30) {
      const a = e.power * 16 * Math.exp(-l / 6);
      shx += a * Math.sin(l * 3.3 + e.t);
      shy += a * Math.cos(l * 4.1 + e.t);
    }
  }
  const aura = I(t, [424, 432, 452, 458], [0, 1, 1, 0], C);
  shx += aura * 3 * Math.sin(frame * 2.3);
  shy += aura * 3 * Math.cos(frame * 1.9);
  const s = zs + pz;
  const cx = pa.x + (pb.x - pa.x) * fw;
  const cam = `translate(${540 + shx} ${1200 + shy}) rotate(${roll}) scale(${s}) translate(${-cx} ${-1200})`;

  // suasana tegang
  const sat = I(t, [350, 380, 428, 440], [1, 0.55, 0.55, 1], C);
  const tension = I(t, [352, 370, 428, 436], [0, 1, 1, 0], C);
  const pulse = [372, 392, 410].reduce((m, b) => (t >= b ? Math.max(m, Math.exp(-(t - b) / 6)) : m), 0);
  const speed = [[248, 262, 0.6], [286, 320, 0.45], [452, 480, 1]].reduce((m, [a, b, k]) => (t >= a && t <= b ? Math.max(m, k * Math.min(1, (t - a) / 3, (b - t) / 3 + 0.2)) : m), 0);
  const bars = I(t, [440, 452], [0, 1], C) * (1 - I(t, [500, 520], [0, 1], C));
  const ghostsA = inR(t, [[286, 322], [452, 486]]), ghostsB = inR(t, [[330, 342], [470, 500]]);

  const hpA = hpAt(t, 'A'), hpB = hpAt(t, 'B'), gA = hpAt(t - 16, 'A'), gB = hpAt(t - 16, 'B');
  const kl = t - 506, wl = t - 545;

  return (
    <AbsoluteFill style={{background: '#000', filter: `saturate(${sat})`}}>
      <svg width={1080} height={1920} viewBox="0 0 1080 1920" style={{position: 'absolute'}}>
        <defs>
          <linearGradient id="sky" gradientUnits="userSpaceOnUse" x1="0" y1="-600" x2="0" y2={GROUND}>
            <stop offset="0" stopColor="#070514" /><stop offset="0.55" stopColor="#1d0b36" /><stop offset="0.85" stopColor="#4a1456" /><stop offset="1" stopColor="#c2410c" />
          </linearGradient>
          <radialGradient id="moon"><stop offset="0" stopColor="#fff4e0" /><stop offset="1" stopColor="#ffc58a" /></radialGradient>
          <linearGradient id="ground" gradientUnits="userSpaceOnUse" x1="0" y1={GROUND} x2="0" y2={GROUND + 600}>
            <stop offset="0" stopColor="#2f1240" /><stop offset="1" stopColor="#07030f" />
          </linearGradient>
          <radialGradient id="aura"><stop offset="0" stopColor="#ffd23f" stopOpacity="0.85" /><stop offset="0.6" stopColor="#ff9a00" stopOpacity="0.35" /><stop offset="1" stopColor="#ff6a00" stopOpacity="0" /></radialGradient>
          <radialGradient id="vig" cx="0.5" cy="0.5" r="0.75"><stop offset="0.45" stopColor="#000" stopOpacity="0" /><stop offset="1" stopColor="#000" stopOpacity="0.85" /></radialGradient>
          <radialGradient id="vigR" cx="0.5" cy="0.5" r="0.75"><stop offset="0.35" stopColor="#7f1d1d" stopOpacity="0" /><stop offset="1" stopColor="#b91c1c" stopOpacity="0.9" /></radialGradient>
        </defs>

        <g transform={cam}>
          <Bg cx={cx} f={frame} />
          <Shadow p={pa} /><Shadow p={pb} />
          {DUST.map((d) => <Dust key={d.t} d={d} t={t} />)}
          <Aura x={pa.x} k={aura} t={t} />
          {ghostsA && [3, 6, 9].map((d, i) => <Stickman key={`ga${d}`} pose={poseAt(A_KEYS, t - d)} dir={1} color={BLUE} dark={BLUE} band="#facc15" t={t} opacity={0.38 - i * 0.11} />)}
          {ghostsB && [3, 6, 9].map((d, i) => <Stickman key={`gb${d}`} pose={poseAt(B_KEYS, t - d)} dir={-1} color={RED} dark={RED} band="#fff" t={t} opacity={0.38 - i * 0.11} />)}
          <Stickman pose={pb} dir={-1} color={RED} dark="#b83a52" band="#ffffff" t={t} glow={RED} />
          <Stickman pose={pa} dir={1} color={aura > 0.5 ? '#9be7ff' : BLUE} dark="#1d6f99" band="#facc15" t={t} glow={aura > 0 ? '#ffd23f' : BLUE} />
          {EVENTS.map((e) => <FX key={e.t} e={e} t={t} />)}
        </g>

        {/* overlay layar */}
        <Speed k={speed} f={frame} />
        <rect width={1080} height={1920} fill="url(#vig)" />
        <rect width={1080} height={1920} fill="url(#vigR)" opacity={tension * (0.35 + 0.5 * pulse)} />
        <rect width={1080} height={1920} fill="#fff" opacity={flash} />
        <rect width={1080} height={110 * bars} fill="#000" />
        <rect y={1920 - 110 * bars} width={1080} height={110 * bars} fill="#000" />

        {/* HUD */}
        <g opacity={1 - bars} transform="translate(20 0) skewX(-10)">
          {[0, 1].map((side) => {
            const hp = side ? hpB : hpA, g = side ? gB : gA, x = side ? 590 : 60;
            const w = (v: number) => (430 * v) / 100;
            return (
              <g key={side}>
                <rect x={x} y={110} width={430} height={36} fill="rgba(0,0,0,.6)" stroke="#fff" strokeWidth={3} />
                <rect x={side ? x + 430 - w(g) : x} y={110} width={w(g)} height={36} fill="#fff" />
                <rect x={side ? x + 430 - w(hp) : x} y={110} width={w(hp)} height={36} fill={hpCol(hp)} />
              </g>
            );
          })}
        </g>
        <g opacity={1 - bars}>
          <Txt x={110} y={98} size={44} fill={BLUE}>BLUE</Txt>
          <Txt x={970} y={98} size={44} fill={RED}>RED</Txt>
          <Txt x={540} y={150} size={64} fill="#ffe066" stroke="#c2185b">VS</Txt>
        </g>

        {/* teks intro & ending */}
        {frame < 56 && <Txt x={540} y={760} size={220} fill="#fff" stroke="#6d28d9" scale={I(frame, [0, 10], [1.6, 1], C)} op={I(frame, [0, 6, 44, 56], [0, 1, 1, 0], C)}>ROUND 1</Txt>}
        {frame >= 58 && frame < 104 && <Txt x={540} y={780} size={280} fill="#ff3b30" stroke="#ffe066" rot={-5} scale={I(frame, [58, 64, 70], [3, 0.9, 1], C)} op={I(frame, [58, 60, 92, 104], [0, 1, 1, 0], C)}>FIGHT!</Txt>}
        {kl >= 0 && <Txt x={540} y={820} size={420} fill="#ff3b30" stroke="#fff" rot={-6} scale={I(kl, [0, 4, 8], [3, 0.9, 1], C)} op={I(kl, [0, 2, 52, 66], [0, 1, 1, 0], C)}>K.O.</Txt>}
        {wl >= 0 && <Txt x={540} y={760} size={190} fill={BLUE} stroke="#fff" scale={I(wl, [0, 8, 14], [0.7, 1.1, 1], C)} op={I(wl, [0, 10], [0, 1], C)}>BLUE WINS!</Txt>}
      </svg>

      {SFX.map((a, i) => (
        <Sequence key={i} from={Math.round(realFrame(a.t))}>
          <Audio src={staticFile(`sfx/${a.n}.wav`)} volume={a.v ?? 1} />
        </Sequence>
      ))}
      <Audio src={staticFile('sfx/bgm.wav')} volume={0.35} />
    </AbsoluteFill>
  );
};
